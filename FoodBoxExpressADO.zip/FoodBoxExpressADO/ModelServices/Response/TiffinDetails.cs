﻿namespace TiffinManagement.ModelServices.Response
{
    public class TiffinDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public string Area { get; set; }
        public int Rating { get; set; }
        public string Review { get; set; }
    }
}
